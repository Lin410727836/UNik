package tw.edu.pu.unik

data class Data(val userIcon: Int
                ,val userName: String
                ,val userLevel: String
                ,val topic: String
                ,val content: String
                ,val picture1: Int
                ,val picture2: Int
                ,val picture3: Int
                ,val love: String
                ,val message: String) {
}